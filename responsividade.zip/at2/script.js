const radio = document.querySelectorAll("input[name='personas']") //verifica se é fotos mesmo
console.log(radio[0].id)
const cntPersonagens = [
    {
        id: "ft1",
        text: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolor doloremque, facilis laboriosam fugiat earum eos animi quam hic, ad, minus possimus sapiente repellendus totam eligendi debitis velit cumque libero corporis.",
        img: "img/circo1.jpg"
    },
    {
        id: "ft2",
        text: "descricao2",
        img: "img/circo2.jpg"
    },
    {
        id: "ft3",
        text: "descricao3",
        img: "img/circo3.jpg"
    },
    {
        id: "ft4",
        text: "descricao4",
        img: "img/circo4.jpg"
    }

]; //preencher objetos

radio.forEach(radio => {
    radio.addEventListener("click", () => {
        const conteudo = cntPersonagens.find(item => item.id === radio.id);
        document.querySelector(".conteudo > div > p").innerHTML = conteudo.text;
        document.querySelector(".conteudo > div > img").src = conteudo.img;
    });
});