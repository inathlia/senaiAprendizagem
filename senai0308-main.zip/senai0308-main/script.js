var db_filmes = {
    "data": [
        {
          "id": 1,
          "personagens" : [
            {"foto": "img/loki.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"},
            {"foto": "img/nath.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"},
            {"foto": "img/scott.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"}
            ],
        },
        {
          "id": 2,
          "personagens" : [
            {"foto": "img/harry.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"},
            {"foto": "img.hermione.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"},
            {"foto": "img/ron.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"}
            ],
        },
       {
          "id": 3,
          "personagens" : [
            {"foto": "img/bambi.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"},
            {"foto": "img/jasmine.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"},
            {"foto": "img/ursulajpg.jpg",
            "historia": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo animi porro ipsum optio aut aliquid illo deleniti est quis? Ullam, maxime magni, earum dignissimos ex debitis ratione quae ipsam, vel necessitatibus quia voluptates aspernatur sapiente labore quas pariatur voluptate vitae iure quis nostrum quod asperiores expedita. Culpa laboriosam dicta ratione?"}
            ],
        },
    ]
}

var db = db_filmes;


const params = new URLSearchParams(location.search);
let id = params.get('id');
console.log(id);

for (i = 0; i < db_filmes.data.length; i++){
    if (id == db_filmes.data[i].id){
        document.getElementById('escorpoFilme').innerHTML = `

    `;
    }
}