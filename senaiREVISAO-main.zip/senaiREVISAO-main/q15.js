var db_produtos = {
    data : [
        {
            cod : 1,
            nome : 'Jogos',
            preco : 3,
            estoque : 'Ilimitado',
        },
        {
            cod : 2,
            nome : 'Inflável (3 minutos)',
            preco : 3,
            estoque : 'Ilimitado',
        },
        {
            cod : 3,
            nome : 'Água Mineral',
            preco : 2.50,
            estoque : 100,
        },
        {
            cod : 4,
            nome : 'Quantão',
            preco : 3,
            estoque : 50,
        },
        {
            cod : 5,
            nome : 'Refrigerante/Suco',
            preco : 3.50,
            estoque : 100,
        },
        {
            cod : 6,
            nome : 'Cachorro Quente',
            preco : 3,
            estoque : 50,
        },
        {
            cod : 7,
            nome : 'Pinhão',
            preco : 3,
            estoque : 50,
        },
        {
            cod : 8,
            nome : 'Pipoca',
            preco : 2,
            estoque : 50,
        },
        {
            cod : 9,
            nome : 'Pizza',
            preco : 3,
            estoque : 50,
        },
        {
            cod : 10,
            nome : 'Carreteiro (Mini porção)',
            preco : 3.50,
            estoque : 50,
        },
        {
            cod : 11,
            nome : 'Bolo de milho',
            preco : 2.50,
            estoque : 50,
        },
        {
            cod : 12,
            nome : 'Algodão doce',
            preco : 3.50,
            estoque : 50,
        }

    ]
}

//total arrecadado
var total = 0;
localStorage.setItem('valorTotal', total)

// function verificar(){
//     let s = document.getElementById('senha').value;
//     let l = document.getElementById('login').value;
//     console.log(s);
//     console.log(l);
//     if(s == 'AdminFesta' && l == 'Admin'){
//         window.location.href = "home.html";
//     }
//     else{
//         alert("Login ou senha incorretos");
//     }
// }

// function venda(){
//     let cod = document.getElementById('codigo').value;
//     let qnt = document.getElementById('quant').value;


// }

// document.getElementById('botaoLogin').addEventListener('click',verificar);