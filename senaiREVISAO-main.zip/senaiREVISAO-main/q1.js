function q1(){
    //alert("teste")
    x = prompt(parseInt("Digite a altura"));
    console.log(`O aprendiz tem: ${x} de altura`);
}

function q2(){
    idade = prompt(parseInt("Digite sua idade"));

    console.log(`O aprendiz nasceu em ${2022-idade} ou ${2021-idade}`);
}

function q3(){
    v1 = prompt(parseInt("Digite um número: "));
    for(i = 1; i <= 10; i++){
        console.log(`${v1*i}\n`);
    }
}

function q4(){
    soma = 0;

    for (i = 0; i <= 100; i++) soma += i;

    console.log(soma);
}

function q5(){
    //alert("teste");
    soma = 0;

    for (i = 0; i <= 500; i+2){
        if (i/2 == 0) soma += i; 
    } 

    console.log(soma);
}

function q6(){
    for (i = 0; i <= 20; i++){
        if (i/2 != 0) console.log(i); 
    } 
}


// document.getElementById('qu1').addEventListener('click',q1);
// document.getElementById('qu2').addEventListener('click',q2);
// document.getElementById('qu3').addEventListener('click',q3);
// document.getElementById('qu4').addEventListener('click',q4);
// document.getElementById('qu5').addEventListener('click',q5);
// document.getElementById('qu6').addEventListener('click',q6);